import unittest,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class Delivery(unittest.TestCase):
 def test_every_image_and_fallback_exists(self):
  art=json.loads((ROOT/'docs/data/artwork.json').read_text());self.assertEqual(len(art),780)
  for sid,a in art.items():
   self.assertTrue((ROOT/'docs'/a['sheet']).is_file(),sid)
   self.assertIn(a['x'],range(4));self.assertIn(a['y'],range(2))
  self.assertTrue((ROOT/'docs/art/default-stox.png').is_file())
 def test_every_catalog_id_is_unique_and_has_news_route(self):
  c=json.loads((ROOT/'docs/data/catalog.json').read_text());ids=[s['Source ID'] for s in c];self.assertEqual(len(ids),1321);self.assertEqual(len(set(ids)),1321)
  report=json.loads((ROOT/'docs/data/scoring-coverage.json').read_text());self.assertEqual(report['eligible'],1321);self.assertEqual(set(ids),{s['id'] for s in report['pieces']})
 def test_pages_entry_and_local_dependencies(self):
  for name in ['docs/index.html','docs/app.js','docs/style.css','docs/vendor/d3.min.js','docs/data/world.geojson','docs/data/states.geojson']:
   self.assertTrue((ROOT/name).is_file(),name)
 def test_no_browser_file_exceeds_github_limit(self):
  for f in (ROOT/'docs').rglob('*'):
   if f.is_file():self.assertLess(f.stat().st_size,25*1024*1024,str(f))
