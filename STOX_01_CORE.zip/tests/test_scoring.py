import sys,unittest
from pathlib import Path
from datetime import datetime,timezone,timedelta
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from update import apply,links,inside
C=[{'Source ID':'a','Name':'Japan','Sentiment Sensitivity':'High'},{'Source ID':'b','Name':'Tourism','Sentiment Sensitivity':'High'},{'Source ID':'c','Name':'Poetry'}]
E={'id':'x','kind':'tsunami','severity':5,'territories':['Japan']}
class Scoring(unittest.TestCase):
 def test_dedup_next_window(self):
  t=datetime(2026,1,1,tzinfo=timezone.utc);a=apply([dict(E)],{},C,t);b=apply([dict(E)],a,C,t+timedelta(hours=8));self.assertEqual(a['prices'],b['prices']);self.assertEqual(a['prices']['a'],95);self.assertEqual(a['prices']['c'],100)
 def test_same_window_waits(self):
  t=datetime(2026,1,1,tzinfo=timezone.utc);a=apply([],{},C,t);b=apply([dict(E)],a,C,t);self.assertEqual(b['prices']['a'],100)
 def test_daily_clamp(self):
  t=datetime(2026,1,1,tzinfo=timezone.utc);a=apply([dict(E,id='x'),dict(E,id='y')],{},C,t);self.assertEqual(a['prices']['a'],95)
 def test_geometry(self):self.assertTrue(inside((1,1),[[0,0],[2,0],[2,2],[0,2]]));self.assertFalse(inside((5,5),[[0,0],[2,0],[2,2],[0,2]]))
if __name__=='__main__':unittest.main()
