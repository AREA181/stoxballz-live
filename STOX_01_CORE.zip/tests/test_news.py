import sys,json,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from news import score_text,CONTEXT,terms
C=json.loads((Path(__file__).resolve().parents[1]/'docs/data/catalog.json').read_text())
class News(unittest.TestCase):
 def test_every_piece_has_a_route(self):
  for s in C:
   headline=s['Name']+(' US state ' if s.get('State Code')=='GA' else ' ')+ ' '.join(CONTEXT[s['Branch']])+' growth success breakthrough improves'
   self.assertIn(s['Source ID'],score_text(headline,[s]),s['Name'])
 def test_neutral_does_not_move(self):
  self.assertEqual(score_text('A report about agriculture and Water resource supply',C),{})
 def test_substrings_do_not_match(self):
  war=[{'Source ID':'x','Name':'War','Branch':'Abstract / Idea'}]
  self.assertEqual(score_text('Award success in society',war),{})
 def test_negative_and_positive(self):
  s=[{'Source ID':'x','Name':'Timber','Branch':'Resource','Sentiment Sensitivity':'High'}]
  self.assertLess(score_text('Timber supply shortage crisis',s)['x']['score'],0)
  self.assertGreater(score_text('Timber supply growth success',s)['x']['score'],0)
 def test_unrelated_category_not_blanket_scored(self):
  s=[{'Source ID':'x','Name':'Timber','Branch':'Resource'},{'Source ID':'y','Name':'Gold','Branch':'Resource'}]
  self.assertNotIn('y',score_text('Timber supply shortage',s))
