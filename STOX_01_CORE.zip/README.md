# STOXballz — The Daily Fix
MONKISM × IGMUS

1,321 catalog entries in 16 categories. 780 exact artwork assignments from the supplied RPG actor records. The 541 confirmed placeholder assignments use the supplied STØX logo. No RPG runtime is needed.

## Deployment
Use START_HERE.html from the delivery ZIP. Its four upload files go into a NEW public repository as files. GitHub Actions unpacks the three ZIP payloads on every run. Keep stoxballz-state.json at the repository root: that is the persistent prices and ledger. The source ZIPs contain a starting snapshot; the workflow always restores the saved root state before collecting.

Do not combine this package with an older source-based deployment. Use a new repository for the simplest installation. To migrate an existing ledger intentionally, copy the old docs/data/state.json into the new repository as stoxballz-state.json before the first workflow run. Keep a backup.

## Behavior
- USGS + GDACS disasters and BBC world/business/technology/science/culture news, plus NASA RSS.
- Every catalog ID has an explicit name/alias matching route, with category context for short or ambiguous terms. The coverage file verifies eligibility, not that every piece receives a real article daily.
- Text displayed is generalized to catalog subjects; source links retain the original reports.
- News polarity uses explicit cue lists. It is a game heuristic and may misread sarcasm, context or names. Balanced and unmatched stories cause zero movement. No paid semantic model is included.
- Disaster severity and signed relevance feed a bounded scoring formula; no random price moves.
- Start at 100; changes in 0.1 increments; combined adjustment capped at ±5 per piece per eight-hour window; floor 0.1. News effects are capped at 2.5 before sensitivity.
- Feed checks run hourly, settlement on the first successful run of each UTC 00/08/16 window. Schedules can be late. Refresh reads published data; it does not force a new collection.
- Exact normalized headlines deduplicate across news feeds; source IDs deduplicate disasters. Different articles about one incident can overlap; full semantic story clustering is not implemented.
- Map markers are reported coordinates. Highlighted territories are reported associations. No tsunami inundation modeling or live confirmed-tsunami adapter is included. Offshore epicenters do not imply nearby territory damage.
- Watchlists are browser-local. No wallet, token transfer, buy/sell or real-money transaction functions.

## Files and verification
scripts/news.py holds news phrase/context/polarity rules. scripts/update.py holds feed ingestion, disaster matching and settlement. docs/data/scoring-coverage.json records all 1,321 eligible entries. docs/data/artwork-audit.json records exact actor-to-sheet mappings. docs/data/rpg-identity.json preserves actor IDs for optional later interoperability. These do not import the RPG engine or its stock scenery.

Run tests with Python 3.12: python -m unittest discover -s tests
Serve locally: python -m http.server 8000 --directory docs
No pip, npm, API keys or paid services are required.

## Hosting boundaries
This is a static public game/news dashboard. GitHub Pages disallows using Pages primarily for commercial transactions or commercial SaaS. Selling tokens, payments or a distributor checkout would require suitable separate hosting. Site size is checked below 1 GB, upload payloads below 25 MiB each. Bandwidth, account permissions, scheduled availability and GitHub's terms still apply. No live GitHub deployment was performed during packaging.

## Attribution
Catalog and concept: MONKISM. Implementation: MONKISM × IGMUS. Artwork supplied by MONKISM. D3 v7: https://github.com/d3/d3 (ISC; see THIRD_PARTY.txt). World geometry: https://github.com/datasets/geo-countries (Natural Earth / geoBoundaries); US states: https://github.com/PublicaMundi/MappingAPI. Sources link to original USGS, GDACS, BBC and NASA bulletins. This is an independent implementation; World Monitor source and the RPG runtime are not included.

Artwork audit: 780 pieces mapped to supplied art slots, 541 use the default logo. Uncertain/conflicting labels fall back rather than being assigned by guesswork.
