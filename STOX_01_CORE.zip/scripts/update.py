"""Public feeds -> deduplicated events -> versioned STOX game ledger. Python stdlib only."""
import json, math, os, re, sys, urllib.request, xml.etree.ElementTree as ET
from datetime import datetime, timezone, timedelta
from email.utils import parsedate_to_datetime
from pathlib import Path
from news import collect_news
ROOT=Path(__file__).resolve().parents[1]; DATA=ROOT/'docs/data'
NOW=datetime.now(timezone.utc)
def read(name,default):
 try:return json.loads((DATA/name).read_text())
 except FileNotFoundError:return default
def request(url):
 req=urllib.request.Request(url,headers={'User-Agent':'STOXballz/1.0 (public educational game dashboard)','Accept':'application/json, application/xml, text/xml, */*'})
 with urllib.request.urlopen(req,timeout=40) as r:return r.read()
def inside(point, ring):
 x,y=point;hit=False
 for i in range(len(ring)):
  a,b=ring[i-1],ring[i]
  if ((a[1]>y)!=(b[1]>y)) and x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0]:hit=not hit
 return hit
def locate(point,geo):
 for f in geo.get('features',[]):
  g=f['geometry']; polys=[g['coordinates']] if g['type']=='Polygon' else g['coordinates'] if g['type']=='MultiPolygon' else []
  for p in polys:
   if inside(point,p[0]) and not any(inside(point,h) for h in p[1:]):return f['properties'].get('name',f['properties'].get('ADMIN',''))
 return None
# Explicit, inspectable concept links. No blanket movement of entire categories.
RULES={
 'earthquake':{'Quake':-1,'Earthquake':-1,'Infrastructure':-0.7,'Road':-0.4,'Bridge':-0.5,'Emergency':0.3,'Rescue':0.4},
 'tsunami':{'Tsunami':-1,'Coast':-0.8,'Port':-0.8,'Shipping':-0.6,'Tourism':-0.5,'Fishing':-0.5,'Rescue':0.4},
 'flood':{'Flood':-1,'Road':-0.6,'Agriculture':-0.6,'Infrastructure':-0.5,'Rescue':0.4},
 'storm':{'Storm':-1,'Port':-0.5,'Shipping':-0.5,'Tourism':-0.5,'Infrastructure':-0.5},
 'wildfire':{'Wildfire':-1,'Forest':-0.8,'Timber':-0.6,'Air':-0.4,'Rescue':0.4},
 'volcano':{'Volcano':-1,'Tourism':-0.4,'Air':-0.4,'Rescue':0.3},
 'drought':{'Drought':-1,'Water':-0.7,'Agriculture':-0.7,'Food':-0.5}}
ALIASES={'United States of America':'United States','United States':'United States','Russian Federation':'Russia','Republic of Korea':'South Korea','Dem. Rep. Korea':'North Korea','Viet Nam':'Vietnam','Türkiye':'Turkey','Czechia':'Czech Republic','Democratic Republic of the Congo':'DR Congo','United Republic of Tanzania':'Tanzania','Republic of the Congo':'Congo'}
def norm(s):return re.sub(r'[^a-z0-9]','',ALIASES.get(s,s).lower())
def links(event,catalog):
 if event['kind']=='news':return event.get('news_effects',{})
 out={}; geo={norm(x) for x in event.get('territories',[])}
 for s in catalog:
  name=s['Name']; relevance=RULES.get(event['kind'],{}).get(name)
  if norm(name) in geo:
   is_us='unitedstates' in geo
   if s.get('State Code','N/A')!='N/A' and not is_us:continue
   if s.get('Country Code')=='GE' and is_us:continue
   relevance=-1
  if relevance is None:continue
  if not geo and norm(name) not in (norm(event['kind']),'quake'):continue
  # Common effects are small; near-five scores require extreme severity.
  strength=event['severity']**3/25
  sensitivity={'Low':0.7,'Medium':0.85,'High':1}.get(s.get('Sentiment Sensitivity'),0.85)
  score=round(max(-5,min(5,strength*relevance*sensitivity)),1)
  if score:out[s['Source ID']]={'score':score,'reason':('Direct geographic match' if norm(name) in geo else 'Explicit '+event['kind']+' concept rule'),'relevance':relevance}
 return out

def collect():
 events=[];status=[]; world=read('world.geojson',{});states=read('states.geojson',{})
 try:
  raw=json.loads(request('https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_day.geojson'))
  for f in raw['features']:
   p=f['properties'];lon,lat,*_=f['geometry']['coordinates'];mag=p.get('mag') or 0
   country=locate((lon,lat),world);state=locate((lon,lat),states) if country in ('United States','United States of America') else None
   # USGS tsunami flag is not a confirmed tsunami footprint; keep it an earthquake.
   events.append({'id':'usgs:'+f['id'],'kind':'earthquake','title':'Earthquake · '+(state or country or 'Offshore region'),'time':datetime.fromtimestamp(p['time']/1000,timezone.utc).isoformat(),'severity':round(min(5,max(.5,(mag-4)*1.1)),1),'coordinates':[lon,lat],'territories':list(filter(None,[country,state])),'source':'USGS','url':p.get('url'),'geometry':None,'area_status':'Reported epicenter; affected extent unavailable'})
  status.append({'source':'USGS','ok':True,'count':len(raw['features'])})
 except Exception as e:status.append({'source':'USGS','ok':False,'error':str(e)[:160]})
 try:
  root=ET.fromstring(request('https://www.gdacs.org/xml/rss.xml'))
  for item in root.findall('.//item'):
   fields={el.tag.split('}')[-1]:el.text for el in item.iter() if el.text}
   typ={'EQ':'earthquake','TC':'storm','FL':'flood','WF':'wildfire','VO':'volcano','DR':'drought','TS':'tsunami'}.get(fields.get('eventtype'))
   if not typ or typ=='earthquake':continue # USGS owns earthquakes: avoid cross-source double scoring.
   country=fields.get('country','');country=country if norm(country) not in ('','unknown') else ''
   try:coords=[float(fields['long']),float(fields['lat'])]
   except (KeyError,ValueError):continue
   start=fields.get('fromdate')
   try:
    started=parsedate_to_datetime(start)
    if started < NOW-timedelta(hours=72):continue
   except (ValueError,TypeError):continue
   level=fields.get('alertlevel','Green');sev={'Green':1.0,'Orange':2.8,'Red':4.5}.get(level,1)
   events.append({'id':'gdacs:'+str(fields.get('eventid') or fields.get('guid')),'kind':typ,'title':typ.title()+' · '+(country or 'Reported region'),'time':fields.get('fromdate') or NOW.isoformat(),'severity':sev,'coordinates':coords,'territories':[country] if country else [],'source':'GDACS','url':fields.get('link'),'geometry':None,'area_status':'Reported location; affected extent unavailable'})
  status.append({'source':'GDACS','ok':True,'count':len(root.findall('.//item'))})
 except Exception as e:status.append({'source':'GDACS','ok':False,'error':str(e)[:160]})
 news,health=collect_news(request,read('catalog.json',[]),NOW)
 events+=news;status+=health
 return list({e['id']:e for e in events}.values()),status

def apply(events,old,catalog,now):
 window=now.strftime('%Y-%m-%d')+'T'+str((now.hour//8)*8).zfill(2)+':00Z'
 ledger=old.get('ledger',{});prices=old.get('prices',{s['Source ID']:100.0 for s in catalog});changes={};settled=old.get('settled_window')
 for e in events:e['effects']=links(e,catalog)
 if settled!=window:
  for e in events:
   if e['id'] in ledger:continue
   for sid,v in e['effects'].items():changes[sid]=changes.get(sid,0)+v['score']
   ledger[e['id']]={'at':now.isoformat(),'effects':e['effects']}
  changes={sid:round(max(-5,min(5,v)),1) for sid,v in changes.items()}
  for sid,v in changes.items():prices[sid]=round(max(.1,prices.get(sid,100)+v),1)
  settled=window
 else:changes=old.get('changes',{})
 return {'version':1,'updated_at':now.isoformat(),'settled_window':settled,'prices':prices,'changes':changes,'ledger':ledger,'events':events,'rule_version':'1.0-explicit-disaster-rules','coverage':'All catalog IDs eligible via explicit name/alias and context matching. Headline sentiment is a transparent heuristic; unmatched or neutral news has zero effect.'}

def main():
 catalog=read('catalog.json',[]);old=read('state.json',{});events,status=collect()
 if not any(s['ok'] for s in status):
  old['feeds']=status;old['last_attempt']=NOW.isoformat();(DATA/'state.json').write_text(json.dumps(old));print('All feeds failed; retained last successful values',file=sys.stderr);return 1
 # Keep recent events from a failing source; never relabel them as newly fetched.
 failed={s['source'] for s in status if not s['ok']}
 events+= [e for e in old.get('events',[]) if e.get('source') in failed]
 result=apply(events,old,catalog,NOW);result['feeds']=status
 history=old.get('history',[])
 if result['settled_window']!=old.get('settled_window'):history.append({'window':result['settled_window'],'changes':result['changes']})
 result['history']=history[-90:];(DATA/'state.json').write_text(json.dumps(result,separators=(',',':')))
 print(json.dumps({'events':len(events),'matched_stox':len(result['changes']),'feeds':status}))
 return 0
if __name__=='__main__':sys.exit(main())
