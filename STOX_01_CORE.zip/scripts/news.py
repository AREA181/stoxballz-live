"""Inspectable lexical news matching. Every catalog ID is eligible; silence is zero."""
import re,hashlib,html,xml.etree.ElementTree as ET
from datetime import datetime,timezone,timedelta
from email.utils import parsedate_to_datetime
FEEDS=[('BBC World','https://feeds.bbci.co.uk/news/world/rss.xml'),('BBC Business','https://feeds.bbci.co.uk/news/business/rss.xml'),('BBC Technology','https://feeds.bbci.co.uk/news/technology/rss.xml'),('BBC Science','https://feeds.bbci.co.uk/news/science_and_environment/rss.xml'),('BBC Culture','https://feeds.bbci.co.uk/news/entertainment_and_arts/rss.xml'),('NASA','https://www.nasa.gov/feed/')]
CONTEXT={
 'Government':['government','law','policy','court','election','public','legislation'],
 'Religion':['religion','faith','church','temple','worship','spiritual'],
 'Geopolitical':['country','state','territory','border','international','diplomatic'],
 'Culture':['art','culture','music','film','book','festival','heritage'],
 'Resource':['resource','commodity','supply','mining','material','production'],
 'Biological':['biology','health','medical','research','disease','science'],
 'Animal':['animal','wildlife','species','conservation','habitat','pet'],
 'Earth / Planetary':['earth','climate','environment','weather','geology','planet'],
 'Cosmic':['space','astronomy','nasa','orbit','universe','planet','cosmic'],
 'Abstract / Idea':['society','social','research','community','philosophy','rights'],
 'Miracles & Mayhem':['disaster','emergency','rescue','crisis','incident','recovery'],
 'Transportation / Movement':['transport','travel','traffic','vehicle','shipping','rail'],
 'Emotion & Tension / Vibe':['mental','health','mood','social','community','psychology'],
 'Occupation Shares':['worker','job','employment','profession','labor','industry','career'],
 'Tools, Weapons & Tech':['technology','tool','equipment','device','defence','engineering'],
 'Venue & Vice':['venue','entertainment','leisure','tourism','hospitality','gambling']}
ALIASES={'Quake':['earthquake','earthquakes'],'Pray':['prayer','prayers'],'Wild':['wildlife'],'Sun':['solar'],'Moon':['lunar'],'Art':['arts'],'AI':['artificial intelligence'],'Tech':['technology'],'Law':['legislation'],'Hunt':['hunting'],'Fish':['fishing'],'Farm':['farming'],'Ship':['shipping'],'Vote':['voting'],'Space':['spaceflight']}
POS=['growth','gain','gains','improves','improved','recovery','recovers','success','successful','breakthrough','boost','boosts','rises','rise','record high','agreement','restored','protects','saved','wins','expands','expansion','discovery','discovers']
NEG=['crisis','loss','losses','decline','declines','falls','fall','shortage','shortages','damage','damaged','disaster','collapse','collapsed','outage','closures','closure','threat','threatens','pollution','cuts','cut','ban','banned','failed','failure','dies','deaths','killed','war','attack','attacks']
def contains(text,term):return bool(re.search(r'(?<!\w)'+re.escape(term.lower())+r'(?!\w)',text.lower()))
def terms(s):return list(dict.fromkeys([s['Name'].lower(),*ALIASES.get(s['Name'],[])]))
def eligible(text,s):
 hits=[t for t in terms(s) if contains(text,t)]
 if s['Name']=='Georgia':
  us=any(contains(text,t) for t in ['US state','U.S. state','United States','Atlanta'])
  if s.get('State Code')=='GA' and not us:return []
  if s.get('Country Code')=='GE' and us:return []
 if not hits:return []
 # Short and ambiguous names require independent category context.
 ambiguous={'may','will','can','state','country','world','time','life','power','change','work','love','hate','hope','fear','peace','war','wild','law','free','light','dark','fire','water','air','earth','space','sun','moon','star','art','ai'}
 if any(len(t)<=3 or t in ambiguous for t in hits):
  if not any(contains(text,k) and k not in hits for k in CONTEXT[s['Branch']]):return []
 return hits
def score_text(text,catalog):
 positive=sum(contains(text,w) for w in POS);negative=sum(contains(text,w) for w in NEG)
 sign=1 if positive>negative else -1 if negative>positive else 0
 strength=min(2.5,.2+.2*abs(positive-negative)) if sign else 0
 effects={}
 for s in catalog:
  hits=eligible(text,s)
  if not hits or not strength:continue
  sensitivity={'Low':.7,'Medium':.85,'High':1}.get(s.get('Sentiment Sensitivity'),.85)
  value=round(sign*strength*sensitivity,1)
  effects[s['Source ID']]={'score':value,'reason':'News phrase match: '+', '.join(hits)+'; '+('positive' if sign>0 else 'negative')+' headline cues. Game heuristic, not factual market impact.','relevance':1,'method':'lexical-news-v1'}
 return effects

def collect_news(request,catalog,now):
 events=[];health=[]
 for source,url in FEEDS:
  try:
   root=ET.fromstring(request(url));items=root.findall('.//item');accepted=0
   for item in items[:35]:
    title=html.unescape(item.findtext('title') or '');link=item.findtext('link') or '';pub=item.findtext('pubDate')
    try:date=parsedate_to_datetime(pub).astimezone(timezone.utc)
    except (ValueError,TypeError):continue
    if date<now-timedelta(hours=48) or date>now+timedelta(hours=1):continue
    effects=score_text(title,catalog)
    if not effects:continue
    matched=[s for s in catalog if s['Source ID'] in effects]
    # Publish only generalized catalog subjects, not the source headline or named people.
    names=list(dict.fromkeys(s['Name'] for s in matched));country=[s['Name'] for s in matched if s.get('Subclass')=='Sovereign Country']
    events.append({'id':'news:'+hashlib.sha256(re.sub(r'\W+',' ',title.lower()).strip().encode()).hexdigest()[:24],'kind':'news','title':'News signal · '+', '.join(names[:3]),'time':date.isoformat(),'severity':max(abs(v['score']) for v in effects.values()),'coordinates':None,'territories':country,'source':source,'url':link,'geometry':None,'area_status':'Headline topic association; no physical affected-area claim','news_effects':effects})
    accepted+=1
   health.append({'source':source,'ok':True,'count':len(items),'matched_articles':accepted})
  except Exception as e:health.append({'source':source,'ok':False,'error':str(e)[:160]})
 return list({e['id']:e for e in events}.values()),health
